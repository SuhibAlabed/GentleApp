package com.example.gentleman_v13;

import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.firestore.FirebaseFirestore;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseFirestore db = FirebaseFirestore.getInstance();


        final Button GuestBtn = (Button) findViewById(R.id.GuestBtn);
        final Button SignUpBtn = (Button) findViewById(R.id.SignUpBtn);
        final Button LoginBtn  = (Button) findViewById(R.id.LoginBtn);

//        Guest Btn
        GuestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent MainPage = new Intent(getApplicationContext(),MainPage.class);
                startActivity(MainPage);
            }
        });


//        SignUp Btn
        SignUpBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent SignUpPage= new Intent(getApplicationContext(),SignUpPage.class);
                startActivity(SignUpPage);
            }
        });

//        Login Btn
        LoginBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent LoginPage= new Intent(getApplicationContext(),LoginPage.class);
                startActivity(LoginPage);
            }
        });
    }
}